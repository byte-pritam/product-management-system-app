package com.ecom.enums;

public enum UserRole {
    ADMIN, CUSTOMER
}
